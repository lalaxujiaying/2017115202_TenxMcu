

#include	"REGtenxTM52F5268b.h"
#include    "typeAlias.h"
#include	"intrins.h"
#include 	"math.h"
#include	"global.h"
#include	"setting.h"
#include	"tkcalculate.h"
#include	"updatebaseline.h"
#include	"tkjudgement.h" 
#include    "tm1628.h"
#include    "display.h"
#include    "buzz.h"
#include    "triac.h"
#include	"tempAd.h"
#include    "main.h"


