#ifndef __DELAY_H_
#define __DELAY_H_

#define u8 unsigned char
#define u16 unsigned int

void delayms_lo(u16 ms);
void delayms_sh(u8 ms);	
#endif